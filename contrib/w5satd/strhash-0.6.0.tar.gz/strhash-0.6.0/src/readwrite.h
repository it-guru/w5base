/*
 * placed in the public domain by Uwe Ohse, uwe@ohse.de.
 */
#ifndef READWRITE_H
#define READWRITE_H

extern int read(int, char *,unsigned int);
extern int write(int, const char *,unsigned int);

#endif
