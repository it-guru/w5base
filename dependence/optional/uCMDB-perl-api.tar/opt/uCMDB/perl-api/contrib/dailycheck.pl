#!/usr/bin/perl
use lib('../');
use WebService::uCMDB;
use Data::Dumper;

my $DefaultBase="https://w5base.net/w5base/auth/";
my ($help,$verbose,$debug,$loginuser,$loginpass,$quiet,$base,$lang);
my %P=("help"=>\$help,
       "host=s"=>\$host,"port=s"=>\$port,"proto=s"=>\$proto,
       "webuser=s"=>\$loginuser,"webpass=s"=> \$loginpass,
       "verbose+"=>\$verbose,"debug"=>\$debug);
my $optresult=XGetOptions(\%P,\&Help,undef,undef);

my $ucmdb=new WebService::uCMDB::Adapter(

      debug=>$debug, user=>$loginuser, password=>$loginpass,
      application=>'W5Base',

      host=>$host, port=>$port, proto=>$proto
);

if (my $msg=$ucmdb->checkClientAdapter()){
   msg(ERROR,$msg);
   exit(255);
}

if (!$ucmdb->ping()){
   msg(ERROR,"uCMDB server seems not to be active");
   exit(255);
}

#######################################################################
#  ---- > end of init - now starting the real job
#######################################################################

$|=1;
#
# Bei diesen Abfragen mu� immer 0 Datens�tze gefunden werden. Wenn nicht,
# dann mu� im einzelnen nachanalysiert werden.
#
if (1){
   foreach my $QueryName ("CheckDoubleApps",
                          "CheckDoubleClusters","CheckDoubleDbs",
                          "CheckDoubleNodes(CS Assets)",
                          "CheckDoubleNodes(CS LogSys)",
                          "CheckDoubleNodes(ISEM)",
                          "CheckDoubleNodesByInterface",
                          "CheckIPsWithoutNode"){
      printf("%-40s ...",$QueryName);
      my $qr=$ucmdb->executeTopologyQueryByName($QueryName);
      if ($qr->success()){
         my $c=$qr->count();
         printf(" results %5d records ",$c);
         if ($c==0){
            printf("OK\n");
         }
         else{
            printf("NOT OK\n");
         }
      }
      else{
         printf("FAIL\n");
      }
   }
}


#
# Doppelte Nodes aus AssetManager d�rften eigentlich nicht auftauchen
#
if (0){
   my $QueryName="CheckDoubleNodes(CS LogSys)";
   printf("%-40s ...",$QueryName);
   my $qr=$ucmdb->executeTopologyQueryByName($QueryName);
   if ($qr->success()){
      my $set=$qr->result();
      my $c=0;
      my $nonpmaisem=0;
      while (my $rec=$set->()){
         if ($rec->{EntryType} eq "CI"){
            my $qd=$ucmdb->getCIsById([$rec->{ID}],
                          $rec->{type}=>[qw(tec_data_source)]);
            if ($qd->success()){
               $c++;
               my @detail=$qd->result();
               $nonpmaisem++; # if ($detail->[0]->{props}->{im_external_source}
                              # ne "PMA-ISEM");
               printf STDERR ("fifi detail=%s\n",Dumper(\@detail));
            }
         }
      }
      if ($c<100 && $nonpmaisem==0){
         printf("OK\n");
      }
      else{
         printf("NOT OK\n");
      }
   }
}


#
# Bei dieser Abfrage sind 20-100 gefundene OK, wenn bei allen das 
# Quell System PMA-ISEM ist - die haben da eine seltsame Definition
# getroffen, die diesen Effekt produziert (weshalb konnte mir Thomas
# auch nicht mehr sagen)
#
if (0){
   my $QueryName="CheckDoubleBizServices";
   printf("%-40s ...",$QueryName);
   my $qr=$ucmdb->executeTopologyQueryByName($QueryName);
   if ($qr->success()){
      my $set=$qr->result();
      my $c=0;
      my $nonpmaisem=0;
      while (my $rec=$set->()){
         if ($rec->{EntryType} eq "CI"){
            my $qd=$ucmdb->getCIsById([$rec->{ID}],
                          $rec->{type}=>[qw(im_external_source)]);
            if ($qd->success()){
               $c++;
               my @detail=$qd->result();
               $nonpmaisem++; # if ($detail->[0]->{props}->{im_external_source}
                              # ne "PMA-ISEM");
               printf STDERR ("fifi detail=%s\n",Dumper(\@detail));
            }
         }
      }
      if ($c<100 && $nonpmaisem==0){
         printf("OK\n");
      }
      else{
         printf("NOT OK\n");
      }
   }
}





#my $qr=$ucmdb->executeTopologyQueryByName("ReferenzAbfrage2");
#
#if ($qr->success()){
#   my $set=$qr->result();
#   my $c=0;
#   while (my $rec=$set->()){
#      if ($rec->{EntryType} eq "CI"){
#         my $qd=$ucmdb->getCIsById([$rec->{ID}],
#                       $rec->{type}=>[qw(name root_class memory_size 
#                                         serial_number create_time im_status)]);
#         if ($qd->success()){
#            my @detail=$qd->result();
#            printf STDERR ("fifi detail=%s\n",Dumper(\@detail));
#         }
#      }
#      printf ("%03d iter %s\n",$c++,Dumper($rec));
#   }
#   printf("Record count=%s\n",$qr->count());
#}





#######################################################################
sub Help
{
   print(<<EOF);
$RealScript [options] FullnameFilter

   --verbose display more details of operation process
   --debug   debug SOAP protocoll calls
   --quiet   only errors would be displayed
   --host    uCMDB host or ip address
   --port    tcp port number of uCMDB webservice
   --proto   webservice base protokoll (http or https)

   --webuser username
   --webpass password
   --store   stores the parameters (not help,verbose and store)
   --help    show this help

EOF
}
#######################################################################
exit(255);

