#!/usr/bin/perl
use lib('../');
use WebService::uCMDB;
use Data::Dumper;

my $DefaultBase="https://w5base.net/w5base/auth/";
my ($help,$verbose,$debug,$loginuser,$loginpass,$quiet,$base,$lang);
my %P=("help"=>\$help,
       "host=s"=>\$host,"port=s"=>\$port,"proto=s"=>\$proto,
       "webuser=s"=>\$loginuser,"webpass=s"=> \$loginpass,
       "verbose+"=>\$verbose,"debug"=>\$debug);
my $optresult=XGetOptions(\%P,\&Help,undef,undef);

my $ucmdb=new WebService::uCMDB::Adapter(

      debug=>$debug, user=>$loginuser, password=>$loginpass,
      application=>'W5Base(sued/surname.givenname)',

      host=>$host, port=>$port, proto=>$proto
);

if (my $msg=$ucmdb->checkClientAdapter()){
   msg(ERROR,$msg);
   exit(255);
}

if (!$ucmdb->ping()){
   msg(ERROR,"uCMDB server seems not to be active");
   exit(255);
}

#######################################################################
#  ---- > end of init - now starting the real job
#######################################################################

$|=1;

if (1){
   #my $qr=$ucmdb->getFilteredCIs("host_node","ALL",{'name'=>$ARGV[0]});  
                               # f.e. host_node => q8nwp%
                               # f.e. business_application => w5base%
   my $qr=$ucmdb->getFilteredCIs($ARGV[0],"ALL",{'name'=>$ARGV[1]});  
                                
   if ($qr->success()){
      my $set=$qr->result();
      my $c=0;
      my $nonpmaisem=0;
      while (my $rec=$set->()){
         printf("rec=%s\n",Dumper($rec));
         # load relations



      }
      printf("... done\n");
   }
   else{
      msg(ERROR,$qr->error());
   }
}



#######################################################################
sub Help
{
   print(<<EOF);
$RealScript [options] FullnameFilter

   --verbose display more details of operation process
   --debug   debug SOAP protocoll calls
   --quiet   only errors would be displayed
   --host    uCMDB host or ip address
   --port    tcp port number of uCMDB webservice
   --proto   webservice base protokoll (http or https)

   --webuser username
   --webpass password
   --store   stores the parameters (not help,verbose and store)
   --help    show this help

EOF
}
#######################################################################
exit(255);

