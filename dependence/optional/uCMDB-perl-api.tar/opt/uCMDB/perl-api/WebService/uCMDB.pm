package WebService::uCMDB;
#  W5Base Framework
#  Copyright (C) 2012  Hartmut Vogler (it@guru.de)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#

=pod

=head1 NAME

WebService::uCMDB - connector to HP uCMDB systems

=begin __INTERNALS

=head1 PORTABILITY

This module is designed to be portable across operating systems
and it currently supports Unix, VMS, DOS, OS/2 and Windows. 

=end __INTERNALS

=cut

use 5.005;
use strict;
use vars qw(@EXPORT @ISA $VERSION);
use Exporter;
use Getopt::Long;
use FindBin qw($RealScript);
use Config;

$VERSION = "0.1";
@ISA = qw(Exporter);
@EXPORT = qw(&msg &ERROR &WARN &DEBUG &INFO $RealScript
             &XGetOptions
             &XGetFQStoreFilename
             &XLoadStoreFile
             &XSaveStoreFile
             &createConfig
             &getModuleObject
             &getUserAgent
             );

sub ERROR() {return("ERROR")}
sub WARN()  {return("WARN")}
sub DEBUG() {return("DEBUG")}
sub INFO()  {return("INFO")}

sub msg
{
   my $type=shift;
   my $msg=shift;
   my $format="\%-6s \%s\n";

   if ($type eq "ERROR" || $type eq "WARN"){
      foreach my $submsg (split(/\n/,$msg)){
         printf STDERR ($format,$type.":",$submsg);
      }
   }
   else{
      foreach my $submsg (split(/\n/,$msg)){
         printf STDOUT ($format,$type.":",$submsg) if ($Main::VERBOSE ||
                                                       $type eq "INFO");
      }
   }
}

#######################################################################
# my special handler
#
# $optresult=XGetOptions(\%ARGPARAM,\&Help,\&preStore,".W5Base",[noautologin=>1|0]);
# msg("INFO","xxx");
#  
sub XGetOptions
{
   my $param=shift;
   my $help=shift;
   my $prestore=shift;
   my $defaults=shift;
   my $storefile=shift;
   my %param=@_;
   my $optresult;

   my $store;
   $param->{store}=\$store if (!defined($param->{store}));
   my $if;
   $param->{'initfile=s'}=\$if if (!defined($param->{'initfile=s'}));

   if (!($optresult=GetOptions(%$param))){
      if (defined($help)){
         &$help();
      }
      exit(1);
   }
   if (${$param->{'initfile=s'}} ne ""){
      if (! (-r ${$param->{'initfile=s'}})){
         printf STDERR ("ERROR: can't read initfile '%s'\n",
                        ${$param->{'initfile=s'}});
         exit(255);
      }
      else{
         $storefile=${$param->{'initfile=s'}};
      }
   }

   $storefile=XGetFQStoreFilename($storefile);

   if (defined(${$param->{help}})){
      &$help();
      exit(0);
   }
   if (defined($prestore)){
      &$prestore($param);
   }
   my $sresult=XLoadStoreFile($storefile,$param);
   if ($sresult){
      printf STDERR ("ERROR: $!\n");
      exit(255);
   }
   if (!defined(${$param->{'webuser=s'}}) && !$param{noautologin}){
      my $u;
      while(1){
         printf("login user: ");
         $u=<STDIN>;
         $u=~s/\s*$//;
         last if ($u ne "");
      }
      ${$param->{'webuser=s'}}=$u;
   }
   if (!defined(${$param->{'webpass=s'}}) && !$param{noautologin}){
      my $p="";
      system("stty -echo 2>/dev/null");
      $SIG{INT}=sub{ system("stty echo 2>/dev/null");print("\n");exit(1)};
      while(1){
         printf("password: ");
         $p=<STDIN>;
         $p=~s/\s*$//;
         printf("\n");
         last if ($p ne "");
      }
      system("stty echo 2>/dev/null");
      $SIG{INT}='default';
      ${$param->{'webpass=s'}}=$p;
   }
   if (${$param->{store}}){
      my $sresult=XSaveStoreFile($storefile,$param);
      if ($sresult){
         printf STDERR ("ERROR: $!\n");
         exit(255);
      }
   }
   if (defined($defaults)){
      &$defaults($param);
   }
   if (defined($param->{'verbose+'}) &&
       ref($param->{'verbose+'}) eq "SCALAR" &&
       ${$param->{'verbose+'}}>0){
      $Main::VERBOSE=1;
      msg(INFO,"using parameters:");
      foreach my $p (sort(keys(%$param))){
         my $pname=$p;
         $pname=~s/=.*$//;
         $pname=~s/\+.*$//;
         msg(INFO,sprintf("%8s = '%s'",$pname,${$param->{$p}}));
      }
      msg(INFO,"-----------------");
   }
   return($optresult);
}

sub XGetFQStoreFilename
{
   my $storefile=shift;
   my $home;
   $storefile=".ucmdb" if ($storefile eq "");
   if ($Config{'osname'} eq "MSWin32"){
      $home=$ENV{'HOMEPATH'};
   }else{
      $home=$ENV{'HOME'};
   }
   if (!($storefile=~m/^\//) &&
       !($storefile=~m/\\/)){ # finding the home directory
      if ($home eq ""){
         eval('
            while(my @pline=getpwent()){
               if ($pline[1]==$< && $pline[7] ne ""){
                  $home=$pline[7];
                  last;
               }
            }
            endpwent();
         ');
      }
      if ($home ne ""){
         $storefile=$home."/".$storefile;
      }
   }
   $storefile=$ENV{'HOMEDRIVE'}.$storefile if ($Config{'osname'} eq "MSWin32");
   return($storefile);
}

sub XLoadStoreFile
{
   my $storefile=shift;
   my $param=shift;

   if (open(F,"<".$storefile)){

      while(my $l=<F>){
         $l=~s/\s*$//;
         if (my ($var,$val)=$l=~m/^(\S+)\t(.*)$/){
            if (exists($param->{$var})){
               if (!(${$param->{store}}) || $var eq "webuser=s" ||
                   $var eq "webpass=s"){
                  if (!defined(${$param->{$var}})){
                     ${$param->{$var}}=unpack("u*",$val);
                  }
               }
            }
         }
      }
      close(F);
   }
   return(0);
}

sub XSaveStoreFile
{
   my $storefile=shift;
   my $param=shift;

   if (open(F,">".$storefile)){
      foreach my $p (keys(%$param)){
         next if ($p=~m/^verbose.*/);
         next if ($p=~m/^help$/);
         next if ($p=~m/^store$/);
         if (defined(${$param->{$p}})){
            my $pstring=pack("u*",${$param->{$p}});
            $pstring=~s/\n//g;
            printf F ("%s\t%s\n",$p,$pstring);
         }
      }
      close(F);
   }
   else{
      return($?);
   }
   return(0);
}


use Data::Dumper;

#sub SOAP::Transport::HTTP::Client::get_basic_credentials
#{
#   my $self=shift;
#   printf STDERR ("fifi self=%s\n",Dumper($self));
##   return(\"$self->{user}\",\"$self->{pass}\");
#}

package WebService::uCMDB::QueryResult;

sub new
{
   my $type=shift;
   my %param=@_;
   my $self=\%param;
   $self=bless($self,$type);
   return($self);
}


sub count
{
   my $self=shift;
   return($self->{totalCount}) if (exists($self->{totalCount}));
   my $set=$self->result();
   my $c=0;
   while ($set->()){$c++}
   return($c);
}

sub result
{
   my $self=shift;
   delete($self->{answerBuffer});
   delete($self->{chunkPointer});
   $self->{recordNumber}=0;
   if (!defined($self->{resultBuffer}) 
       && $self->{numberOfChunks}>0){
      # load first chunk
      my $res=$self->{ucmdb}->pullTopologyMapChunks(1,$self->{numberOfChunks},
                                     $self->{chunksKey1},$self->{chunksKey2});
      $self->{resultBuffer}=$self->{ucmdb}->_prepairTopologyResult($res,
                                       $self->{_prepairResultParameter});
      $self->{chunkPointer}=1;
   }
   if (defined($self->{resultBuffer})){
      if (!defined($self->{answerBuffer})){
         my @l=@{$self->{resultBuffer}};
         $self->{answerBuffer}=\@l;
         if (wantarray()){
            return(@{$self->{answerBuffer}});
         }
      }
      return(sub{
         my $r=shift(@{$self->{answerBuffer}});
         if (!defined($r)){
            if ($self->{numberOfChunks}>0){
               if ($self->{chunkPointer}<$self->{numberOfChunks}){
                  $self->{chunkPointer}++;
                  my $res=$self->{ucmdb}->pullTopologyMapChunks(
                                          $self->{chunkPointer},
                                          $self->{numberOfChunks},
                                          $self->{chunksKey1},
                                          $self->{chunksKey2});
                  $self->{resultBuffer}=$self->{ucmdb}->_prepairTopologyResult(
                                             $res,
                                             $self->{_prepairResultParameter});
                  my @l=@{$self->{resultBuffer}};
                  $self->{answerBuffer}=\@l;
                  my $r=shift(@{$self->{answerBuffer}});
                  $self->{recordNumber}++;
                  return($r);
               }
               else{
                  delete($self->{chunkPointer});
                  delete($self->{resultBuffer});
                  $self->{totalCount}=$self->{recordNumber};
                  return();
               }
            }
         }
         if (!defined($r)){
            $self->{totalCount}=$self->{recordNumber};
            delete($self->{answerBuffer});
         }
         else{
            $self->{recordNumber}++;
         }
         return($r);
      });
   }
   return();
}

sub success
{
   my $self=shift;
   return(1) if (!($self->{errorcode}));
   return(0);
}


sub errorcode
{
   my $self=shift;
   return(undef) if ($self->success());
   return($self->{errorcode});
}

sub error
{
   my $self=shift;
   return(undef) if ($self->success());
   return($self->{error});
}

package WebService::uCMDB::Adapter;
use Data::Dumper;

sub new
{
   my $type=shift;
   my %param=@_;
   # parameter validation
   my @paramok=qw(debug user password application 
                  host port proto);
   foreach my $p (keys(%param)){
      my $qp=quotemeta($p);
      if (!grep(/^$qp$/,@paramok)){
         WebService::uCMDB::msg(WebService::uCMDB::ERROR,
            "WebService::uCMDB::Adapter invalid parameter '$p' to new method");
         exit(255);
      }
   }
   my $self=\%param;
   $self=bless($self,$type);

   #$self->{'uri'}='http://tempuri.org/' if (!defined($self->{'uri'}));
   $self->{'uri'}='"http://schemas.hp.com/ucmdb' if (!defined($self->{'uri'}));
   $self->{'debug'}=0 if (!defined($self->{'debug'}));
   $self->{'url'}=$self->{'proto'}."://".
                  $self->{'host'}.":".
                  $self->{'port'}."/axis2/services/UcmdbService";

   return($self);
}

sub checkClientAdapter
{
   my $self=shift;

   if (!defined($self->{SOAP})){
      if ($self->{'debug'}){
         eval("use SOAP::Lite +trace=>'all';");
      }
      else{
         eval("use SOAP::Lite;");
      }
      if ($@ ne ""){
         return($@);
      }
      my $SOAP;
      eval('$SOAP=$self->_SOAP();');
      if ($@ ne ""){
         return($@);
      }
      if (!defined($SOAP)){
         return("SOAP Endpoint not createable");
      }
      $self->{SOAP}=$SOAP;
      my $agent=$self->{SOAP}->transport;
      $agent->credentials("$self->{host}:$self->{port}",
                          "CMDB_OPEN_API",$self->{user},$self->{password});
   }
   return();
}


sub ping
{
   my $self=shift;

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $agent=$self->{SOAP}->transport;
   if (!defined($agent)){
      die('can not find transport object');
   }
   my $r=$agent->get($self->_url('ping'));
   if (!defined($r) || !$r->is_success()){
      return(0);
   }
   if ($r->content ne "Active"){
      return(0);
   }
   return(1);
}

sub executeTopologyQuery
{
   my $self=shift;
   my $QueryName=shift;
   my $attr=shift;
   my $param=shift;   # every parameter must be exists as Name Paramter in query
   my $SOAPmethod="executeTopologyQueryByName";

   $attr=[]  if (!ref($attr));
   if (defined($param)){
      $SOAPmethod="executeTopologyQueryByNameWithParameters";
      $param={} if (!ref($param));
   }

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $SOAP=$self->{SOAP};

   my @SOAPparam=($self->_uCMDB_SOAP_Context());
   push(@SOAPparam,
         SOAP::Data->name("queryName")
            ->type("")->prefix('quer')->value($QueryName));

   if (defined($param)){
      push(@SOAPparam, SOAP::Data->name("parameterizedNodes")
                          ->type("")
                          ->prefix('quer')
                          ->value($self->_addQueryParameters($param)));
   }
   push(@SOAPparam, SOAP::Data->name("queryTypedProperties")
                       ->type("")
                       ->prefix('quer')
                       ->value($self->_addQueryAttributes($attr)));


   my $QueryResult=new WebService::uCMDB::QueryResult('ucmdb'=>$self);
   my $method = SOAP::Data->name($SOAPmethod)->prefix('quer');
   my $res=$SOAP->call($method=>@SOAPparam);
   if (!defined($res) || ($@=~m/Connection refused/)){
      $QueryResult->{errorcode}=255;
      $QueryResult->{error}="Connection refused or connection problem";
   }
   else{
      if (!$res->fault()){
         my $numberOfChunks=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/numberOfChunks");
         if ($numberOfChunks>0){
            my $chunksKey1=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key1");
            my $chunksKey2=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key2");
            $QueryResult->{numberOfChunks}=$numberOfChunks;
            $QueryResult->{chunksKey1}=$chunksKey1;
            $QueryResult->{chunksKey2}=$chunksKey2;
         }
         else{
            $QueryResult->{resultBuffer}=
               $self->_prepairTopologyResult($res->result());
         }
      }
      else{
         $QueryResult->{errorcode}=$res->faultcode;
         $QueryResult->{error}=$res->faultstring;
         if ($QueryResult->{error} eq "1"){
            $QueryResult->{error}="unexpeced SOAP error";
         }
      }
   }
   return($QueryResult);
}

sub getCITAttr
{
   my $self=shift;
   my $classname=shift;
   my $recurse=shift;
   my $initres=shift;
   my $SOAPmethod="getCmdbClassDefinition";

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $SOAP=$self->{SOAP};

   my @SOAPparam=($self->_uCMDB_SOAP_Context("clas"));


   push(@SOAPparam,
         SOAP::Data->name("className")
            ->type("")->prefix('clas')->value($classname));


   my $QueryResult=new WebService::uCMDB::QueryResult('ucmdb'=>$self);
   my $method = SOAP::Data->name($SOAPmethod)->prefix('clas');
   my $res=$SOAP->call($method=>@SOAPparam);
   if (!defined($res) || ($@=~m/Connection refused/)){
      $QueryResult->{errorcode}=255;
      $QueryResult->{error}="Connection refused or connection problem";
   }
   else{
      if (!$res->fault()){
         my $r=$res->result();
         my $resrec={};
         my $qparent;
         if (defined($initres)){
            $resrec=$initres;
            $resrec->{classlevel}++;
         }
         if ($r->{name} ne ""){
            #printf STDERR ("fifi found name=$r->{name}\n");
            if (!defined($resrec->{name})){
               $resrec->{name}=$r->{name};
               $resrec->{label}=$r->{displayLabel};
               $resrec->{class}=$r->{classType};
               $resrec->{parent}=[];
               $resrec->{attr}={};
            }
            if ($r->{parentName} ne ""){
               push(@{$resrec->{parent}},$r->{parentName});
               $qparent=$r->{parentName};
            }
            if (ref($r->{attributes}) eq "HASH"){
               my $a=$r->{attributes};
               my $attrlist=$r->{attributes}->{attribute};
               $attrlist=[$attrlist] if (ref($attrlist) ne "ARRAY");
               foreach my $attr (@$attrlist){
                  my %ae;
                  if (ref($attr) eq "HASH"){
                     $ae{name}=$attr->{name};
                     $ae{label}=$attr->{displayLabel};
                     $ae{description}=$attr->{description};
                     $ae{type}=$attr->{attrType};
                     $resrec->{attr}->{$ae{name}}=\%ae;
                  }
               }
               #printf STDERR ("fifi 03 = %s\n",Dumper($attrlist));
            }
            #printf STDERR ("d=%s\n",join(",",keys(%{$resrec->{attr}})));
            #printf STDERR ("p=%s\n",join(",",@{$resrec->{parent}}));
            
         }
         if ($recurse && $qparent ne "" && $qparent ne "none"){
            return($self->getCITAttr($qparent,1,$resrec));
            $QueryResult->{resultBuffer}=
                       [$self->getCITAttr($qparent,1,$resrec)];
            # hier mu� u.U. noch ein Fehlerhandling rein!
            return($QueryResult);
         }
         $QueryResult->{resultBuffer}=[$resrec];
         return($QueryResult);
      }
      else{
         $QueryResult->{errorcode}=$res->faultcode;
         $QueryResult->{error}=$res->faultstring;
         if ($QueryResult->{error} eq "1"){
            $QueryResult->{error}="unexpeced SOAP error";
         }
      }
   }
   return($QueryResult);



}

sub getCIsById
{
   my $self=shift;
   my $ids=shift;
   my %attr=@_;
   my $SOAPmethod="getCIsById";

   $ids=[$ids] if (ref($ids) ne "ARRAY");

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $SOAP=$self->{SOAP};

   my @SOAPparam=($self->_uCMDB_SOAP_Context());

   my @typedProperties;
   foreach my $t (keys(%attr)){
      my $a=$attr{$t};
      my @propertiesList;
      $a=[$a] if (ref($a) ne "ARRAY");
      foreach my $aname (@$a){
         push(@propertiesList,
              SOAP::Data->name("propertyName")
                 ->type("")->prefix('prop')->value($aname));
      }
      push(@typedProperties,
         SOAP::Data->name("typedProperties")
                 ->type("")->prefix('prop')->value([
            SOAP::Data->name("type")
                 ->type("")->prefix('prop')->value($t),
            SOAP::Data->name("properties")
                 ->type("")->prefix('prop')->value([
               SOAP::Data->name("propertiesList")
                    ->type("")->prefix('prop')->value(\@propertiesList)
            ])
          ])
        );


   }
   push(@SOAPparam,
         SOAP::Data->name("CIsTypedProperties")
            ->type("")->prefix('quer')->value(\@typedProperties));

   my @IDs;

   foreach my $id (@$ids){
      push(@IDs,
            SOAP::Data->name("ID")
               ->type("")->prefix('typ')->value($id));
   }
   push(@SOAPparam,
         SOAP::Data->name("IDs")
            ->type("")->prefix('quer')->value(\@IDs));

   my $QueryResult=new WebService::uCMDB::QueryResult('ucmdb'=>$self);
   my $method = SOAP::Data->name($SOAPmethod)->prefix('quer');
   my $res=$SOAP->call($method=>@SOAPparam);
   if (!defined($res) || ($@=~m/Connection refused/)){
      $QueryResult->{errorcode}=255;
      $QueryResult->{error}="Connection refused or connection problem";
   }
   else{
      if (!$res->fault()){
         my $numberOfChunks=$res->valueof(
            "//Body/${SOAPmethod}Response/chunkInfo/numberOfChunks");
         if ($numberOfChunks>0){
            my $chunksKey1=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key1");
            my $chunksKey2=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key2");
            $QueryResult->{numberOfChunks}=$numberOfChunks;
            $QueryResult->{chunksKey1}=$chunksKey1;
            $QueryResult->{chunksKey2}=$chunksKey2;
         }
         else{
            $QueryResult->{resultBuffer}=
               $self->_prepairTopologyResult($res->result());
         }
      }
      else{
         $QueryResult->{errorcode}=$res->faultcode;
         $QueryResult->{error}=$res->faultstring;
         if ($QueryResult->{error} eq "1"){
            $QueryResult->{error}="unexpeced SOAP error";
         }
      }
   }
   return($QueryResult);
}



sub getNeighbours
{
   my $self=shift;
   my $classname=shift;
   my $attr=shift;
   my $ID=shift;
   my $_prepairResultParameter=shift;
   my $SOAPmethod="getCINeighbours";

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $SOAP=$self->{SOAP};

   my @SOAPparam=($self->_uCMDB_SOAP_Context());
   push(@SOAPparam,
         SOAP::Data->name("ID")
            ->type("")->prefix('quer')->value($ID));

   push(@SOAPparam,
         SOAP::Data->name("neighbourType")
            ->type("")->prefix('quer')->value($classname));

   my $QueryResult=new WebService::uCMDB::QueryResult('ucmdb'=>$self);
   # preprocess ATTR for "labled groups handling"
   if ($attr eq "ALL"){
      my $qr=$self->getCITAttr($classname,1);
     
      if ($qr->success()){
         my $set=$qr->result();
         if (my $rec=$set->()){
            $attr=[keys(%{$rec->{attr}})];
         }
      }
      else{
         $QueryResult->{errorcode}=$qr->errorcode;
         $QueryResult->{error}=$qr->error;
         return($QueryResult);
      }
   }

   push(@SOAPparam, SOAP::Data->name("CIProperties")
                       ->type("")
                       ->prefix('quer')
                       ->value($self->_addQueryAttributes($attr)));



   my $method = SOAP::Data->name($SOAPmethod)->prefix('quer');
   my $res=$SOAP->call($method=>@SOAPparam);
   if (!defined($res) || ($@=~m/Connection refused/)){
      $QueryResult->{errorcode}=255;
      $QueryResult->{error}="Connection refused or connection problem";
   }
   else{
      if (!$res->fault()){
         my $numberOfChunks=$res->valueof(
            "//Body/${SOAPmethod}Response/chunkInfo/numberOfChunks");
         if ($numberOfChunks>0){
            my $chunksKey1=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key1");
            my $chunksKey2=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key2");
            $QueryResult->{numberOfChunks}=$numberOfChunks;
            $QueryResult->{chunksKey1}=$chunksKey1;
            $QueryResult->{chunksKey2}=$chunksKey2;
         }
         else{
            $QueryResult->{_prepairResultParameter}=$_prepairResultParameter;
            $QueryResult->{resultBuffer}=
               $self->_prepairTopologyResult($res->result(),
                        $QueryResult->{_prepairResultParameter});
         }
      }
      else{
         $QueryResult->{errorcode}=$res->faultcode;
         $QueryResult->{error}=$res->faultstring;
         if ($QueryResult->{error} eq "1"){
            $QueryResult->{error}="unexpeced SOAP error";
         }
      }
   }
   return($QueryResult);
}

sub getFilteredCIs
{
   my $self=shift;
   my $classname=shift;
   my $attr=shift;
   my $condition=shift;
   my $SOAPmethod="getFilteredCIsByType";

   if (defined($condition) && ref($condition) eq "HASH" &&
       keys(%$condition)==1 && defined($condition->{__LinkedToID})){
      return($self->getNeighbours($classname,$attr,
                                  $condition->{__LinkedToID},
                                  {
                                     CIclassname=>[$classname]
                                  }));
   }

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $SOAP=$self->{SOAP};

   my @SOAPparam=($self->_uCMDB_SOAP_Context());
   push(@SOAPparam,
         SOAP::Data->name("type")
            ->type("")->prefix('quer')->value($classname));

   my $QueryResult=new WebService::uCMDB::QueryResult('ucmdb'=>$self);
   # preprocess ATTR for "labled groups handling"
   if ($attr eq "ALL"){
      my $qr=$self->getCITAttr($classname,1);
     
      if ($qr->success()){
         my $set=$qr->result();
         if (my $rec=$set->()){
            $attr=[keys(%{$rec->{attr}})];
         }
      }
      else{
         $QueryResult->{errorcode}=$qr->errorcode;
         $QueryResult->{error}=$qr->error;
         return($QueryResult);
      }
   }

   my @propertiesList;
   foreach my $a (@$attr){
      push(@propertiesList,
          SOAP::Data->name("propertyName")
               ->type("")->prefix('prop')->value($a));
   }

   push(@SOAPparam,
          SOAP::Data->name("properties")
               ->type("")->prefix('quer')->value([
             SOAP::Data->name("propertiesList")
                  ->type("")->prefix('prop')->value(\@propertiesList)
          ])
        );


   if (defined($condition)){
      push(@SOAPparam, SOAP::Data->name("conditions")
                          ->type("")
                          ->prefix('quer')
                          ->value($self->_addQueryConditions($condition)));
      if (ref($condition) eq "HASH"){
         push(@SOAPparam,SOAP::Data->name("conditionsLogicalOperator")
                       ->type("")
                       ->prefix('quer')
                       ->value("AND"));
      }
   }


   my $method = SOAP::Data->name($SOAPmethod)->prefix('quer');
   my $res=$SOAP->call($method=>@SOAPparam);
   if (!defined($res) || ($@=~m/Connection refused/)){
      $QueryResult->{errorcode}=255;
      $QueryResult->{error}="Connection refused or connection problem";
   }
   else{
      if (!$res->fault()){
         my $numberOfChunks=$res->valueof(
            "//Body/${SOAPmethod}Response/chunkInfo/numberOfChunks");
         if ($numberOfChunks>0){
            my $chunksKey1=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key1");
            my $chunksKey2=$res->valueof(
               "//Body/${SOAPmethod}Response/chunkInfo/chunksKey/key2");
            $QueryResult->{numberOfChunks}=$numberOfChunks;
            $QueryResult->{chunksKey1}=$chunksKey1;
            $QueryResult->{chunksKey2}=$chunksKey2;
         }
         else{
            $QueryResult->{resultBuffer}=
               $self->_prepairTopologyResult($res->result());
         }
      }
      else{
         $QueryResult->{errorcode}=$res->faultcode;
         $QueryResult->{error}=$res->faultstring;
         if ($QueryResult->{error} eq "1"){
            $QueryResult->{error}="unexpeced SOAP error";
         }
      }
   }
   return($QueryResult);
}

sub pullTopologyMapChunks
{
   my $self=shift;
   my $chunkNumber=shift;
   my $numberOfChunks=shift;
   my $chunksKey1=shift;
   my $chunksKey2=shift;
   my $SOAPmethod="pullTopologyMapChunks";

   if (my $msg=$self->checkClientAdapter()){
      die($msg);
   }
   my $SOAP=$self->{SOAP};

   my @SOAPparam=($self->_uCMDB_SOAP_Context());
   push(@SOAPparam,
         SOAP::Data->name("ChunkRequest")
            ->type("")->prefix('typ')->value(
            [
              SOAP::Data->name("chunkNumber")
                 ->type("")->prefix('typ')->value($chunkNumber),

              SOAP::Data->name("chunkInfo")
                 ->type("")->prefix('typ')->value([
                 SOAP::Data->name("numberOfChunks")
                    ->type("")->prefix('typ')->value($numberOfChunks),


                 SOAP::Data->name("chunksKey")
                    ->type("")->prefix('typ')->value([

                     SOAP::Data->name("key1")
                        ->type("")->prefix('typ')->value($chunksKey1),
                     SOAP::Data->name("key2")
                        ->type("")->prefix('typ')->value($chunksKey2)

                 ])
              ])
            ])
         );

   my $QueryResult=new WebService::uCMDB::QueryResult('ucmdb'=>$self);
   my $method = SOAP::Data->name($SOAPmethod)->prefix('quer');
   my $res=$SOAP->call($method=>@SOAPparam);
   return($res->result());
}

sub _addQueryAttributes
{
   my $self=shift;
   my $attr=shift;

   my %a;

   if (ref($attr) eq "ARRAY"){
      foreach my $a (@$attr){
         if (my ($ci,$attr)=$a=~m/^([^\.]+)\.(.*)$/){
            if (!defined($a{$ci})){
               $a{$ci}=[$attr];
            }
            else{
               push(@{$a{$ci}},$attr);
            }
         }
         else{
            push(@{$a{'data'}},$a);
         }
      }
   }
   my @l;

   foreach my $ci (keys(%a)){
      my @propertyList;
      foreach my $attr (@{$a{$ci}}){
         push(@propertyList,SOAP::Data->name("propertyName")
                    ->type("")
                    ->prefix('prop')
                    ->value($attr));
      }
      push(@l,SOAP::Data->name("typedProperties")
                    ->type("")
                    ->prefix('prop')
                    ->value([
                       SOAP::Data->name("type")
                         ->type("")
                         ->prefix('prop')
                         ->value($ci),
                       SOAP::Data->name("properties")
                         ->type("")
                         ->prefix('prop')
                         ->value([
                          SOAP::Data->name("propertiesList")
                            ->type("")
                            ->prefix('prop')
                            ->value(\@propertyList)
                          ])
                       ])
                     );
   }
   return(\@l);
}

sub _addQueryParameters
{
   my $self=shift;
   my $param=shift;
   return([]) if (ref($param) ne "HASH");

   my @l;



   my $label="data";
   foreach my $pname (keys(%$param)){
      my $parametername=$pname;
      if (my ($p1,$p2)=$pname=~m/^([^\.]+)\.(.*)$/){
         $parametername=$p2;
         $label=$p1;
      }
      push(@l,SOAP::Data->name("parameters")
                    ->type("")
                    ->prefix('typ')
                    ->value([
                       SOAP::Data->name("strProps")
                         ->type("")
                         ->prefix('typ')
                         ->value([
                          SOAP::Data->name("strProp")
                            ->type("")
                            ->prefix('typ')
                            ->value([
                             SOAP::Data->name("name")
                               ->type("")
                               ->prefix('typ')
                               ->value($parametername),
                             SOAP::Data->name("value")
                               ->type("")
                               ->prefix('typ')
                               ->value($param->{$pname})
                             ])
                          ])
                       ])
                     );
   }
   push(@l,SOAP::Data->name("nodeLabel")
                 ->type("")
                 ->prefix('typ')
                 ->value($label));

   return(\@l);
}

sub _addQueryConditions
{
   my $self=shift;
   my $cont=shift;

   my @l;

   if (ref($cont) eq "ARRAY"){  # handle list of cont in OR (not implemented)


   }
   elsif (ref($cont) eq "HASH"){  # handle list of cont in AND
      my @strCondLike;
      my @strCondIn;
      my @strCondEqual;

      foreach my $pname (keys(%$cont)){
         my $v=$cont->{$pname};
         my $op="Like";
         if (ref($v) eq "SCALAR"){
            $v=[$$v];
            $op="Equal";
         }
         elsif (ref($v) eq "ARRAY"){
            if ($#{$v}==0){
               $op="Equal";
            }
            else{
               $op="In";
            }
         }
         else{
            $v=[$v];
            $op="LikeIgnoreCase";
         }
         if ($op eq "LikeIgnoreCase" ||
             $op eq "Equal"){
            foreach my $vval (@$v){
               push(@strCondLike,
                    SOAP::Data->name("strCondition")
                           ->type("")
                           ->prefix('typ')
                           ->value([
                               SOAP::Data->name("condition")
                                 ->type("")
                                 ->prefix('typ')
                                 ->value([
                                  SOAP::Data->name("name")
                                    ->type("")
                                    ->prefix('typ')
                                    ->value($pname),
                               
                                  SOAP::Data->name("value")
                                    ->type("")
                                    ->prefix('typ')
                                    ->value($vval)
                               ]),
                               SOAP::Data->name("strOperator")
                                 ->type("")
                                 ->prefix('typ')
                                 ->value($op)
                        ])
                );
            }
         }
      }
      if ($#strCondLike!=-1){
         push(@l, SOAP::Data->name("strConditions")
                          ->type("")
                          ->prefix('typ')
                          ->value(\@strCondLike)
         ); 
      }
   }



#   my $label="data";
#   foreach my $pname (keys(%$param)){
#      my $parametername=$pname;
#      if (my ($p1,$p2)=$pname=~m/^([^\.]+)\.(.*)$/){
#         $parametername=$p2;
#         $label=$p1;
#      }
#      push(@l,SOAP::Data->name("parameters")
#                    ->type("")
#                    ->prefix('typ')
#                    ->value([
#                       SOAP::Data->name("strProps")
#                         ->type("")
#                         ->prefix('typ')
#                         ->value([
#                          SOAP::Data->name("strProp")
#                            ->type("")
#                            ->prefix('typ')
#                            ->value([
#                             SOAP::Data->name("name")
#                               ->type("")
#                               ->prefix('typ')
#                               ->value($parametername),
#                             SOAP::Data->name("value")
#                               ->type("")
#                               ->prefix('typ')
#                               ->value($param->{$pname})
#                             ])
#                          ])
#                       ])
#                     );
#   }

   return(\@l);
}

sub _uCMDB_SOAP_Context
{
   my $self=shift;
   my $prefix=shift;

   $prefix="quer" if ($prefix eq "");

   return(SOAP::Data->name("cmdbContext")
             ->type("")->prefix($prefix)->value(
                [SOAP::Data->name("callerApplication")
                    ->type("")
                    ->prefix('typ')
                    ->value($self->{'application'})])
        );
}

sub _SOAP
{
   my $self=shift;

   if ($self->{'url'} eq ""){
      die('no url as communication endpoint specifed');
   }
   my $SOAP=SOAP::Lite->uri($self->{'uri'})
                      ->proxy($self->_url('service'))
                      ->xmlschema("2001");
   $SOAP->serializer->register_ns(
         "http://schemas.hp.com/ucmdb/1/params/query",'quer');
   $SOAP->serializer->register_ns(
         "http://schemas.hp.com/ucmdb/1/types",'typ');
   $SOAP->serializer->register_ns(
          "http://schemas.hp.com/ucmdb/1/params/classmodel",'clas');
   $SOAP->serializer->register_ns(
          "http://schemas.hp.com/ucmdb/1/types/props",'prop');

   return($SOAP);
}

sub _url
{
   my $self=shift;
   my $mode=shift;
 
   if ($mode eq "service"){
      return($self->{'proto'}."://".
             $self->{'host'}.":".
             $self->{'port'}."/axis2/services/UcmdbService");
   }
   if ($mode eq "ping"){
      return($self->{'proto'}."://".
             $self->{'host'}.":".
             $self->{'port'}."/ping");
   }
   die('unexpected _url request'); 
}

sub _decodeProps
{
   my $self=shift;
   my $props=shift;

   my %newrec;
   if (ref($props) eq "HASH"){
      foreach my $vt (keys(%{$props})){
         if (ref($props->{$vt}) eq "HASH"){
            foreach my $vn (keys(%{$props->{$vt}})){
               my $el=$props->{$vt}->{$vn};
               $el=[$el] if (ref($el) ne "ARRAY");
               foreach my $entry (@{$el}){
                  $newrec{$entry->{name}}=$entry->{value};
                  if (my ($Y,$M,$D,$h,$m,$s)=$newrec{$entry->{name}}
                      =~m/^(\d{4})-(\d+)-(\d+)T(\d+):(\d+):(\d+)\.\d+Z$/){
                     $newrec{$entry->{name}}=
                     sprintf("%04d-%02d-%02d %02d:%02d:%02d",$Y,$M,$D,$h,$m,$s);
                  }
               }
            }
         }
      }
   }
   return(\%newrec);
}

sub _prepairTopologyResult
{
   my $self=shift;
   my $r=shift;
   my $param=shift;
   my @r;

   $param={} if (!defined($param));

#   printf STDERR ("fifi d=%s\n",Dumper($r));
   if (exists($r->{'CIs'}) && exists($r->{'CIs'}->{'CI'})){
      $r->{'CI'}=$r->{'CIs'}->{'CI'};
      delete($r->{'CIs'});
   }
   if (exists($r->{'CI'})){
      my @tmpr;
      if (ref($r->{'CI'}) eq "ARRAY"){
         @tmpr=@{$r->{'CI'}}
      }
      else{
         @tmpr=($r->{'CI'});
      }
      foreach my $ci (@tmpr){
         my %rec=%$ci;
         if (exists($rec{props})){
            $rec{Attr}=$self->_decodeProps($rec{props}); 
            delete($rec{props});
         }
         if (!exists($param->{CIclassname}) ||
             grep(/^$rec{type}$/,@{$param->{CIclassname}})){
            push(@r,\%rec);
         }
      }
   }
   if (exists($r->{'CINodes'}) &&
       ref($r->{'CINodes'}) eq "HASH" &&
       exists($r->{'CINodes'}->{'CINode'})){
      my $n=$r->{'CINodes'}->{'CINode'};
      $n=[$n] if (ref($n) ne "ARRAY");
      foreach my $ci (@$n){
         if (ref($ci->{'CIs'}->{'CI'}) eq "HASH"){
            my %rec;
            %rec=%{$ci->{'CIs'}->{'CI'}};
            $rec{Label}=$ci->{label};
            $rec{EntryType}='CI',
            $rec{Attr}=$self->_decodeProps($ci->{props}); 
            if (!exists($param->{CIclassname}) ||
                grep(/^$rec{type}$/,@{$param->{CIclassname}})){
               push(@r,\%rec);
            }
         }
         elsif (ref($ci->{'CIs'}->{'CI'}) eq "ARRAY"){
            foreach my $cirec (@{$ci->{'CIs'}->{'CI'}}){
               my %rec;
               %rec=%{$cirec};
               $rec{Label}=$ci->{label};
               $rec{EntryType}='CI',
               $rec{Attr}=$self->_decodeProps($cirec->{props}); 
               delete($rec{props});
               if (!exists($param->{CIclassname}) ||
                   grep(/^$rec{type}$/,@{$param->{CIclassname}})){
                  push(@r,\%rec);
               }
            }
         }
      }
      delete($r->{'CINodes'});
   }
   if (exists($r->{'relationNodes'}) &&
       ref($r->{'relationNodes'}) eq "HASH" &&
       exists($r->{'relationNodes'}->{'relationNode'})){
      my $n=$r->{'relationNodes'}->{'relationNode'};
      $n=[$n] if (ref($n) ne "ARRAY");
      foreach my $ci (@$n){
         if (ref($ci->{'relations'}->{'relation'}) eq "HASH"){
            my %rec;
            %rec=%{$ci->{'relations'}->{'relation'}};
            $rec{label}=$ci->{label};
            $rec{EntryType}='RELATION',
            push(@r,\%rec);
         }
         elsif (ref($ci->{'relations'}->{'relation'}) eq "ARRAY"){
            foreach my $cirec (@{$ci->{'relations'}->{'relation'}}){
               my %rec;
               %rec=%{$cirec};
               $rec{label}=$ci->{label};
               $rec{EntryType}='RELATION',
               push(@r,\%rec);
            }
         }
      }
      delete($r->{'CINodes'});
   }
   return(\@r);
}


1;
