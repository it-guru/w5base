// Used by GUI.rc
//
#define IDI_DEFAULTICON                 102
#define IDC_HSPLIT 	                    103
#define IDC_VSPLIT 	                    104
